from gui.dialogs.analysis.correlation import CorrelationPlotter
from gui.dialogs.analysis.importance import ImportancePlotter
from gui.dialogs.analysis.targets import TargetPlotter
from gui.dialogs.analysis.variance import VariancePlotter
from gui.dialogs.analysis.tuning import TuningImportancePlotter