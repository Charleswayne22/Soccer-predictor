from enum import Enum


class ClassificationTask(Enum):
    Result = 'Result'
    Over = 'U-O'
